const config = require("./package.json")
exports.handler = (event, context) => {
    let version = JSON.parse(config).version
    console.log(event, context, version)
}
