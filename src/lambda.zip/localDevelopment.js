const handler = require('./handler')

console.log(handler.handler("thing", "thing1"))